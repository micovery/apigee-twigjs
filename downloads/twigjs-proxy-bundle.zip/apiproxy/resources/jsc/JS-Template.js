var template = '                                                     \n\
{% for topic, messages in topics %}                                  \n\
    * {{ loop.index }}: {{ topic }}                                  \n\
  {% for message in messages %}                                      \n\
      - {{ loop.parent.loop.index }}.{{ loop.index }}: {{ message }} \n\
  {% endfor %}                                                       \n\
{% endfor %}                                                         \n\
';

var data = {
    'topics': {
        'topic1': ['Message 1 of topic 1', 'Message 2 of topic 1'],
        'topic2': ['Message 1 of topic 2', 'Message 2 of topic 2'],
    },
};

var template = twigjs.twig({data: template});
var output = template.render(data);

context.setVariable('response.content', output);